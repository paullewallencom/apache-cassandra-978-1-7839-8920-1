$ brew install cassandra
$ pip install cassandra-driver cql
$ cassandra
